# **DougDougGo JS**

* DougDougGo 將是你獨一無二的搜尋引擎！（DougDoug 其實也是使用 DuckDuckGo）

## 內容：
- 新的 favicon
- 當搜尋內容包含 "ike" 將顯示以及播放 ["You just searched Ike, dumbass" 以及切換 favicon](https://www.youtube.com/watch?v=JsYWZSTbEPU)

**建議與 [DougDougify](https://addons.mozilla.org/zh-TW/firefox/addon/youtube-dougdougify/) 一起使用**

## 銘謝
- DougDoug：靈感來自於他
- MagicJinn：提供建議、測試者、以及在開發過程中有困難時幫忙我

歡迎到[GitHub](https://github.com/olivertzeng/DougDougGo)提供任何建議！
