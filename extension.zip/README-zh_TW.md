# **DougDougGo**
![DougDougGo](assets/bigDark.png)

* DougDougGo 將是你獨一無二的搜尋引擎！（DougDoug 其實也是使用 DuckDuckGo）

## 內容：
- 新的 favicon
- 當搜尋內容包含 "ike" 將顯示以及播放 ["You just searched Ike, dumbass" 以及切換 favicon](https://www.youtube.com/watch?v=JsYWZSTbEPU)
- 如果搜尋任何從 Super Smash Bros. Ultimate 中任何出現過的角色將顯示 "You just searched ???,
  dumbass"

 > [!IMPORTANT]
 > # DougDougGo ublocklist
 > - 為了使文字可以正常顯示請訂閱 [這個 ublocklist](https://subscribe.adblockplus.org/?location=https://raw.githubusercontent.com/olivertzeng/DougDOugGo/master/dougdouggo.txt&title=DougDougGo Blocklist) 到 uBlock Origin。也可以參考[我自製（講起來有點怪？）](https://subscribe.adblockplus.org/?location=https://raw.githubusercontent.com/olivertzeng/dotfiles/master/ublocklist.txt&title=Oliver Tzeng's Custom Blocklist) 的 blocklist
 > 使用說明：請從 FireFox 擴充套件商店安裝 [uBlock
 > Origin](https://addons.mozilla.org/zh-TW/firefox/addon/ublock-origin/?utm_source=addons.mozilla.org&utm_medium=referral&utm_content=search) 然後點擊上面的連結。開啟連結後點擊右上角的「訂閱」按鈕以完成安裝。
 > - 為了使擴充功能能夠正常播放聲音，請在 about:preferences 中啟用自動播放功能。

**建議與 [DougDougify](https://addons.mozilla.org/zh-TW/firefox/addon/youtube-dougdougify/) 一起使用**

## 銘謝
- DougDoug：靈感來自於他
- MagicJinn：提供建議、測試者、以及在開發過程中有困難時幫忙我

## 申明
- 這些程式並沒有與 Duck Duck Go, Inc. 產生任何關聯
- 目前並沒有要上架到 Chrome 擴充套件商店的計畫。不過你可以在申明是我（Oliver
  Tzeng）所做的情況下重新在 Chrome 擴充套件商店上上架。

歡迎到[GitHub](https://github.com/olivertzeng/DougDougGo)上提供任何建議！
